import requests
import  json,sys
import datetime
import schedule
import time
from datetime import date,timedelta,timezone,datetime
from geopy.geocoders import Nominatim
import psycopg2
from psycopg2.extensions import AsIs
from psycopg2.extras import Json,DictCursor
import uuid



#################### Postgres ########################
#TO SELECT ANYHING FROM JSON COLUMNS USE
# SELECT col.name->> 'json_key' AS my_column_name FROM weather_data

#WHERE col.name ->>'json_key'='whatever';
######################################################
def dbOpen():
    try:
        connection=psycopg2.connect(host="localhost",
                                    database="openMap",
                                    user="your_username",
                                    password="your_password")
        cursor=connection.cursor()
    except (Exception, psycopg2.Error) as error:
        print("Error while fetching data from PostgreSQL", error)
    return connection,cursor

#closing db fun
def dbClose(connection,cursor):
    if connection:
        cursor.close()
        connection.close()
        print("PostgreSQL connection is closed")


#bringing the points table
def dbBring(cursor):
    latitude=[]
    longitude=[]
    postgreSQL_query="SELECT latitude,longitude FROM grc_weather_checks"
    cursor.execute(postgreSQL_query)
    records=cursor.fetchall()
    for column in records:
        latitude.append(column[0])
        longitude.append(column[1])

    return latitude,longitude

#if BBOX same as dbBring/
def dbBringBBOX(cursor,latmin,latmax,lonmin,lonmax):
    latitude=[]
    longitude=[]
    postgreSQL_query="SELECT latitude,longitude FROM grc_weather_checks WHERE ((latitude>=%f) AND (latitude<=%f) AND(longitude>=%f) AND (longitude<=%f));" %(latmin,latmax,lonmin,lonmax)
    cursor.execute(postgreSQL_query)
    records=cursor.fetchall()
    for column in records:
        latitude.append(column[0])
        longitude.append(column[1])

    return latitude,longitude



#creating partional tables
def tableCreation(cursor,connection,flag):
    name="weather"+str(date.today().year)+"_"+str(date.today().month)
    if flag==1:
        commands=["""CREATE TABLE %s () INHERITS (weather_data);""" %(name),
                """CREATE INDEX %s_dt ON %s (dt);""" %(name,name)]
        for i in commands:
            cursor.execute(i)
        connection.commit()
    else:
        if date.today().day!=1:
            return
        else:
            commands=["""CREATE TABLE %s () INHERITS (weather_data);""" %(name),
                     """CREATE INDEX %s_dt ON %s (dt);""" %(name,name)]
            for i in commands:
                cursor.execute(i)
            connection.commit()

#creating main table
def createCurrentTable(cursor,connection):
    commands="""
        CREATE TABLE weather_data (
            lat double precision NOT NULL ,
            lon double precision NOT NULL ,
            dt TIMESTAMP,
            weather json,
            temp REAL,
            feels_like REAL,
            temp_min REAL,
            temp_max REAL,
            pressure SMALLINT,
            humidity SMALLINT,
            sea_level SMALLINT,
            grnd_level SMALLINT,
            visibility SMALLINT,
            wind json,
            clouds SMALLINT,
            sys json,
            geom GEOMETRY,
            PRIMARY KEY (lat,lon,dt)
        )
        """
    #for command in commands:
    cursor.execute(commands)
    connection.commit()

#insert data from dict and creating geometry col
def insertAndUpdate(lati,longi,vdict,connection):#,cur,connection):
    cur=connection.cursor(cursor_factory=DictCursor)
    insert = "insert into weather_data (%s) values %s;"
    l = [(c, v) for c, v in vdict.items()]
    columns = ','.join([t[0] for t in l])
    values = tuple([t[1] for t in l])
    sql=cur.mogrify(insert, ([AsIs(columns)] + [values]))
    geom="update weather_data SET geom=(ST_GeomFromText('POINT(%s %s)',4326)) WHERE (lat=%s AND lon=%s);" %(str(longi),str(lati),lati,longi)
    cur.execute(sql)
    cur.execute(geom)
    connection.commit()
    cur.close()

#data dictionary
def createDict(datacurrent):
    vdict={}
    lati=datacurrent['coord']['lat']
    longi=datacurrent['coord']['lon']
    vdict['lat']=lati
    vdict['lon']=longi
    vdict['dt']=datetime.fromtimestamp(datacurrent['dt'])
    vdict['weather']=Json(datacurrent['weather'][0])
    for i in datacurrent['main']:
        vdict[i]=datacurrent['main'][i]
    vdict['visibility']=datacurrent['visibility'] 
    vdict['wind']=Json(datacurrent['wind'])
    vdict['clouds']=datacurrent['clouds']['all']
    vdict['sys']=Json(datacurrent['sys'])
    return lati,longi,vdict




#creating postgres Trig Fun
def triggerFun(cursor,connection,flag):
    name="weather"+str(date.today().year)+"_"+str(date.today().month)
    if flag==1:
        commands=["""
            CREATE OR REPLACE FUNCTION weather_data_insert_trigger()
            RETURNS TRIGGER AS $$
            BEGIN
                IF ( NEW.dt >= TIMESTAMP '%s-%s-01 00:00:00' AND
                    NEW.dt < TIMESTAMP '%s-%s-01 00:00:00' ) THEN
                    INSERT INTO %s VALUES (NEW.*);
                ELSE
                    RAISE EXCEPTION 'Date out of range.  Fix the weather_data_insert_trigger() function!';
                END IF;
                RETURN NULL;
            END;
            $$
            LANGUAGE plpgsql;
            """%(str(date.today().year),str(date.today().month),str(date.today().year),str(int(date.today().month)+1),name),
            """CREATE TRIGGER insert_weather_data_trigger
                    BEFORE INSERT ON weather_data
                    FOR EACH ROW EXECUTE PROCEDURE weather_data_insert_trigger();"""]
        for i in commands:
            cursor.execute(i)
        connection.commit()
    else:
        if date.today().day!=1:
            return
        else:
            if date.today().month!=12:
                commands=["""
                    CREATE OR REPLACE FUNCTION weather_data_insert_trigger()
                    RETURNS TRIGGER AS $$
                    BEGIN
                        IF ( NEW.dt >= TIMESTAMP '%s-%s-01 00:00:00' AND
                            NEW.dt < TIMESTAMP '%s-%s-01 00:00:00' ) THEN
                            INSERT INTO %s VALUES (NEW.*);
                        ELSE
                            RAISE EXCEPTION 'Date out of range.  Fix the weather_data_insert_trigger() function!';
                        END IF;
                        RETURN NULL;
                    END;
                    $$
                    LANGUAGE plpgsql;
                    """%(str(date.today().year),str(date.today().month),str(int(date.today().year)+1),str(int(date.today().month)+1),name)]
                for i in commands:
                    cursor.execute(i)
                connection.commit()
                return
            else:
                commands=["""
                    CREATE OR REPLACE FUNCTION weather_data_insert_trigger()
                    RETURNS TRIGGER AS $$
                    BEGIN
                        IF ( NEW.dt >= TIMESTAMP '%s-%s-01 00:00:00' AND
                            NEW.dt < TIMESTAMP '%s-%s-01 00:00:00' ) THEN
                            INSERT INTO %s VALUES (NEW.*);
                        ELSE
                            RAISE EXCEPTION 'Date out of range.  Fix the weather_data_insert_trigger() function!';
                        END IF;
                        RETURN NULL;
                    END;
                    $$
                    LANGUAGE plpgsql;
                    """%(str(date.today().year),str(date.today().month),str(int(date.today().year)+1),str(1),name)]
                for i in commands:
                    cursor.execute(i)
                connection.commit()




def current(lat,lon,api_key,connection):
   flag=0
   #cur=connection.cursor(cursor_factory=DictCursor)
   dt=time.time()
   t=time.time()
   for i in range(len(lat)):
       current="https://api.openweathermap.org/data/2.5/weather?lat=%s&lon=%s&appid=%s&units=metric"% (
               str(lat[i]), str(lon[i]), api_key)
       responsecurrent = requests.get(current)
       datacurrent = json.loads(responsecurrent.text) 
       lati,longi,vdict=createDict(datacurrent)
       insertAndUpdate(lati,longi,vdict,connection)#cur,connection)
       flag=flag+1
       if flag==60:
          print("60")
          t1=time.time()
          dt=t1-t
          if dt>60:
              continue
          else:
              print('wait')
              t1=0
              time.sleep(60-dt)
              flag=0 
              t=0 
              t=time.time()  
              print('start again')
       else:
           continue
   print('finished')
   #cur.close()





def main():
    try:  
       connection,cursor=dbOpen()
       lat,lon=dbBring(cursor)
       ############### FOR BBOX DATA ########################
       #lat,lon=dbBringBBOX(cursor,37.0,40.4,18.501,22.430) 
       ######################################################
       name="weather"+str(date.today().year)+"_"+str(date.today().month)

       
       
       cursor.execute("select exists(select * from information_schema.tables where table_name=%s)", ('weather_data',))
       if cursor.fetchone()[0]==False:
           createCurrentTable(cursor,connection)
       else:
           cursor.execute("DROP TRIGGER IF EXISTS insert_weather_data_trigger ON weather_data;") 
           connection.commit()
        
       api_key = "API key"

       schedule.every().day.at("00:00").do(tableCreation,cursor,connection,2)
       schedule.every().day.at("00:00").do(triggerFun,cursor,connection,2)

       schedule.every().hour.at(":01").do(current,lat,lon,api_key,connection)
       schedule.every().hour.at(":31").do(current,lat,lon,api_key,connection)
       
       

       cursor.execute("select exists(select * from information_schema.tables where table_name=%s)", (name,))
       if cursor.fetchone()[0]==False:
           tableCreation(cursor,connection,1) 
       triggerFun(cursor,connection,1) 

       
       if ((int(datetime.now().minute)>=1 and int(datetime.now().minute)<=20) or (int(datetime.now().minute)>=31 and int(datetime.now().minute)<50)):
           current(lat,lon, api_key,connection)    
           
           
       
       while True:
           schedule.run_pending()

    except KeyboardInterrupt:
        print("Closing")
        dbClose(connection,cursor)
        sys.exit(0)



main()
